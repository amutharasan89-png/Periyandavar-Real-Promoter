பெரியாண்டவர் ரியல் புரமோட்டர் — Android App Project

இந்த ZIP என்பது Android Studio-வில் திறந்து APK உருவாக்குவதற்கான project source.
இது இன்னும் compile செய்யப்பட்ட APK அல்ல.

அம்சங்கள்:
• Buyer / Seller contacts தனித்தனியாக
• பெயர், தொலைபேசி, WhatsApp, இடம், சொத்து வகை, பட்ஜெட்/விலை, lead source, follow-up, status, notes
• Search, Call, WhatsApp
• தொடர்புகள் மொபைலிலேயே சேமிப்பு
• CSV / JSON backup export; import
• App-இல் இருந்து தனி கோப்பாக save செய்ய Android save dialog
• Offline-ஆக அடிப்படை contacts அம்சங்கள் இயங்கும்

APK உருவாக்க:
1. கணினியில் Android Studio நிறுவவும்.
2. Android Studio → Open → இந்த ZIP-ஐ extract செய்த folder-ஐ தேர்வு செய்யவும்.
3. Gradle sync முடியும் வரை காத்திருக்கவும்.
4. Build → Build Bundle(s) / APK(s) → Build APK(s) தேர்வு செய்யவும்.
5. APK பொதுவாக app/build/outputs/apk/debug/app-debug.apk இல் உருவாகும்.
6. அந்த APK-ஐ உங்கள் Android மொபைலுக்கு அனுப்பி நிறுவவும். நிறுவும் போது Android கேட்கும் அனுமதியை வழங்க வேண்டியிருக்கலாம்.

கவனம்:
• இந்த சூழலில் Android SDK/Gradle build tools இல்லாததால் APK-ஐ இங்கே compile செய்து சரிபார்க்க முடியவில்லை.
• Excel export-க்கு இணைய இணைப்பு தேவைப்படலாம்; CSV / JSON export-ஐ backup-க்கு பயன்படுத்தலாம்.
• App data இந்த மொபைலின் app storage-ல் இருக்கும். மொபைல் மாற்றம்/அப்பை uninstall செய்வதற்கு முன் JSON backup எடுக்கவும்.
